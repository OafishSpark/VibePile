"""event_viewer — просмотр и ручная разметка последовательностей событий.

Tkinter + matplotlib: графики «величина(время)» с общей осью времени и таблица событий
с общим выделением.
"""
from .panels import Panel, Points, Segments
from .plot import EventPlot
from .table import EventTable
from .viewer import EventViewer

__all__ = ["EventViewer", "EventPlot", "EventTable", "Panel", "Points", "Segments"]
__version__ = "0.1.0"
