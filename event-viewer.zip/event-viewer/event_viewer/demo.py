"""Демо на синтетических данных: python -m event_viewer"""
from __future__ import annotations

import tkinter as tk

import numpy as np
import pandas as pd

from .panels import Segments
from .viewer import EventViewer


def make_demo(seed: int = 0, n: int = 1000) -> pd.DataFrame:
    """Случайные события за час: точки p0, p1, отрезки p2 -> p2_end, p3 -> p3_end."""
    rng = np.random.default_rng(seed)
    seconds = np.sort(rng.uniform(0, 3600, n))
    df = pd.DataFrame(
        {"time": pd.Timestamp("2026-01-01") + pd.to_timedelta(seconds, unit="s"),
         "dur": pd.to_timedelta(rng.uniform(1, 10, n), unit="s")},
        index=pd.Index(np.arange(1, n + 1), name="event_id"),
    )
    for k in range(4):
        df[f"p{k}"] = rng.normal(size=n) * 10 ** k
    df["p2_end"] = df["p2"] + rng.normal(scale=50, size=n)
    df["p3_end"] = df["p3"] + rng.normal(scale=500, size=n)
    df["channel"] = rng.choice(["A", "B", "C"], size=n)  # есть только в таблице
    return df


def main(n_sets: int = 3) -> dict[int, pd.Index]:
    """Последовательно разметить n_sets наборов. Возвращает {номер набора: метки}."""
    root = tk.Tk()
    root.geometry("1300x750")
    viewer = EventViewer(root, time_col="time", panels=[
        "p0",
        "p1",
        Segments(start="p2", end="p2_end", duration="dur"),
        Segments(start="p3", end="p3_end", duration="dur"),
    ])
    viewer.pack(fill=tk.BOTH, expand=True)

    results: dict[int, pd.Index] = {}
    for i in range(n_sets):
        root.title(f"Набор {i + 1} из {n_sets}")
        viewer.load(make_demo(seed=i))
        marked = viewer.wait_next()
        if marked is None:  # окно закрыли
            break
        results[i] = marked
        print(f"Набор {i + 1}: выделено {len(marked)}")
    else:
        root.destroy()
    return results
