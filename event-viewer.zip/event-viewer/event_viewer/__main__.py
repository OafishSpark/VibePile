"""Демо: python -m event_viewer"""
from .demo import main

main()
