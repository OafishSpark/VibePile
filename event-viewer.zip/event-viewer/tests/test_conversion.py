import numpy as np
import pandas as pd

from event_viewer.conversion import duration_to_float, to_float, to_text


def test_to_text():
    assert to_text(pd.Series([1.23456, -2.0])) == ["1.235", "-2.000"]
    assert to_text(pd.Series([1, 2])) == ["1", "2"]
    assert to_text(pd.to_timedelta(pd.Series([1.5]), unit="s")) == ["1.500"]
    assert to_text(pd.Series(pd.to_datetime(["2026-01-01 00:00:01.25", None]))) == \
        ["2026-01-01 00:00:01.250", ""]


def test_duration_units():
    sec = pd.Series([86400.0])
    assert duration_to_float(sec, time_is_datetime=True, unit="s")[0] == 1.0
    assert duration_to_float(pd.to_timedelta(sec, unit="s"), time_is_datetime=True)[0] == 1.0
    assert duration_to_float(pd.Series([2000.0]), time_is_datetime=True, unit="ms")[0] == \
        2 / 86400
    assert duration_to_float(sec, time_is_datetime=False)[0] == 86400.0


def test_to_float_dtype():
    assert to_float(pd.Series([1, 2])).dtype == np.float64
    t = to_float(pd.Series(pd.to_datetime(["2026-01-01", "2026-01-02"])))
    assert t.dtype == np.float64 and t[1] - t[0] == 1.0
