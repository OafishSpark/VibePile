"""Smoke-тест GUI. Пропускается, если нет дисплея (на сервере: xvfb-run pytest)."""
import tkinter as tk

import numpy as np
import pandas as pd
import pytest

from event_viewer import EventViewer, Segments
from event_viewer.demo import make_demo


@pytest.fixture
def viewer():
    try:
        root = tk.Tk()
    except tk.TclError:
        pytest.skip("нет дисплея")
    v = EventViewer(root, "time", ["p0", Segments("p2", "p2_end", "dur")],
                    table_cols=["channel", "p0"], font=("TkDefaultFont", 12))
    v.pack(fill=tk.BOTH, expand=True)
    v.load(make_demo(n=200), selected=[5, 10])
    root.update()
    yield v
    try:
        root.destroy()
    except tk.TclError:  # окно уже закрыто в тесте
        pass


def test_load_and_selection(viewer):
    assert sorted(viewer.selected_index) == [5, 10]
    headers = [viewer.table.tree.heading(c)["text"] for c in viewer.table.tree["columns"]]
    assert headers == ["event_id", "channel", "p0"]
    viewer.toggle(0)
    assert viewer.selected[0] and viewer.table.tree.item("0", "tags") == ("sel",)
    viewer.clear_selection()
    assert not viewer.selected.any()


def test_center_point_follows_selection(viewer):
    artists = viewer.plot._artists  # scatter p0, линии p2, точки-центры p2
    assert len(artists) == 3
    viewer.toggle(3)
    sel_rgba = viewer.plot._palette[1]
    for a in artists:
        np.testing.assert_allclose(a.get_edgecolor()[3] if a.get_facecolor().size == 0
                                   else a.get_facecolor()[3], sel_rgba)


def test_save(viewer, tmp_path):
    path = viewer.save_selected(str(tmp_path / "out.csv"))
    assert sorted(pd.read_csv(path, index_col=0).index) == [5, 10]


def test_wait_next_and_close(viewer):
    viewer.after(100, viewer._next_btn.invoke)
    assert sorted(viewer.wait_next()) == [5, 10]
    viewer.after(100, viewer.winfo_toplevel().destroy)
    assert viewer.wait_next() is None
