import numpy as np

from event_viewer.geometry import seg_dist2, seg_in_rect

SEG = np.array([
    [[0, 0], [10, 10]],    # диагональ через окно
    [[5, 5], [5, 5]],      # точка внутри
    [[20, 0], [30, 0]],    # далеко справа
    [[0, 10], [10, 20]],   # выше окна
    [[np.nan, 0], [1, 1]], # NaN
], dtype=np.float64)


def test_in_rect_any_part():
    assert seg_in_rect(SEG, 4, 6, 4, 6).tolist() == [True, True, False, False, False]


def test_in_rect_middle_only():
    seg = np.array([[[0, 0], [10, 0]]], dtype=np.float64)  # концы снаружи, середина внутри
    assert seg_in_rect(seg, 4, 6, -1, 1).tolist() == [True]


def test_dist2():
    d2 = seg_dist2(SEG, (5, 0))
    np.testing.assert_allclose(d2[:4], [12.5, 25, 225, 125])
    assert np.isinf(d2[4])
